
export default props => props.children;